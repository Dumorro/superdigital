﻿using System.Threading.Tasks;
using MassTransit;
using MassTransitExample.Messages;
using Microsoft.Extensions.Logging;

namespace MassTransitExample.Subscriber.Console.Consumers
{
    public class LancamentoConsumer : IConsumer<Lancamento>
    {
        private readonly ILogger<LancamentoConsumer> _logger;

        public LancamentoConsumer(ILogger<LancamentoConsumer> logger)
        {
            _logger = logger;
        }

        public Task Consume(ConsumeContext<Lancamento> context)
        {

            _logger.LogInformation($"Order processed: FlightId:{context.Message}");

            return Task.CompletedTask;
        }
    }

}