# MassTransit Demo

Sample demo dot net app demonstrating how to send a message onto a queue using MassTransit and publishing and consuming message via Azure Service Bus.